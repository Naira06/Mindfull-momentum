using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ScoreManage : MonoBehaviour
{
    public Text score;        // the Text component for displaying the score
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // Update the score text to display the current score obtained from the RandomDigit script.
        score.text = "Your Score: " + RandomDigit.currentScore.ToString();
    }
}
