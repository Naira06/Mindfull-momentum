using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RandomDigit : MonoBehaviour
{
    public Text digitText;
    public GameObject maskedCircle;

    private int currentDigit;
    public static int currentScore =  0;
    private float toggleInterval = 1.0f;
    private float toggleTimer = 0f;
    private float maskedCircleDelay = 2.0f;
    private float maskedCircleTimer = 0f;
    private bool isDigitHidden = false;

    private void Start()
    {
        InvokeRepeating("GenerateRandomDigit", 0.5f, 2.0f);
    }

    private void Update()
    {
        toggleTimer += Time.deltaTime;

        if (toggleTimer >= toggleInterval)
        {
            ToggleDigitVisibility();
            toggleTimer = 0f;
        }

        if (isDigitHidden)
        {
            maskedCircleTimer += Time.deltaTime;

            if (maskedCircleTimer >= maskedCircleDelay)
            {
                ShowMaskedCircle();
                maskedCircleTimer = 0f;
            }
        }
        else
        {
            maskedCircleTimer += Time.deltaTime;

            if (maskedCircleTimer >= maskedCircleDelay)
            {
                HideDigit();
                maskedCircleTimer = 0f;
            }
        }

        if (!isDigitHidden && Input.GetKeyDown(KeyCode.Space))
        {
            if (currentDigit == 3)
            {
                SceneManager.LoadScene("endScene");
            }
            else{
                currentScore+=1;
                
            }
        }
    }

    private void GenerateRandomDigit()
    {
        currentDigit = Random.Range(1, 10);
        digitText.text = currentDigit.ToString();
        ToggleDigitVisibility();
    }

    private void ToggleDigitVisibility()
    {
        digitText.gameObject.SetActive(!digitText.gameObject.activeSelf);
        isDigitHidden = !digitText.gameObject.activeSelf;
        maskedCircle.SetActive(isDigitHidden);
        maskedCircleTimer = 0f;
    }

    private void HideDigit()
    {
        digitText.gameObject.SetActive(false);
        isDigitHidden = true;
        maskedCircle.SetActive(true);
        maskedCircleTimer = 0f;
    }

    private void ShowMaskedCircle()
    {
        maskedCircle.SetActive(false);
        isDigitHidden = false;
        digitText.gameObject.SetActive(true);
    }
}